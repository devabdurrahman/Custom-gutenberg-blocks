<?php 
// Prevent direct access to the file
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

use Carbon_Fields\Block;
use Carbon_Fields\Field;

Block::make( __( 'Carousel' ) )
	->add_fields( array(
		Field::make( 'media_gallery', 'cbf-media-gallery', __( 'Creat Carousel' ) ),
	) )
	->set_category( 'cbf-blocks-category', __( 'CBF Blocks' ), 'cbf-blocks' )
	->set_render_callback( function ( $fields, $attributes, $inner_blocks ) {
		?>

		<div class="block carousel-container">
			<div class="main-gallery js-flickity">
				<?php
					foreach($fields['cbf-media-gallery'] as $image){
						?>
						<div class="carousel-cell">
							<?php 

							echo wp_get_attachment_image($image, 'large');

							 ?>
						</div>
						<?php
					}
				?>
			</div>			
		</div><!-- /.block -->

		<?php
	} );