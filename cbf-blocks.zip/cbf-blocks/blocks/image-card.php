<?php 
// Prevent direct access to the file
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

use Carbon_Fields\Block;
use Carbon_Fields\Field;

Block::make( __( 'CBF Image Card' ) )
    ->add_fields( array(
        Field::make( 'image', 'cbf-image-card', __( 'Image Background' ) ),
        Field::make( 'text', 'cbf-heading-card', __( 'Heading' ) ),
        Field::make( 'rich_text', 'cbf-content-card', __( 'Description' ) )
    ) )
    ->set_category( 'cbf-blocks-category', __( 'CBF Blocks' ), 'cbf-blocks' )
    ->set_render_callback( function ( $fields, $attributes, $inner_blocks ) {
        ?>

        <figure class="snip1527">
          <div class="image"><?php echo wp_get_attachment_image( $fields['cbf-image-card'], 'full' ); ?></div>
          <figcaption>
            <div class="date"><span class="day">28</span><span class="month">Oct</span></div>
            <h3><?php echo esc_html( $fields['cbf-heading-card'] ); ?></h3>
            <?php echo apply_filters( 'the_content', $fields['cbf-content-card'] ); ?>
          </figcaption>
          <a href="#"></a>
        </figure>

        <?php
    } );