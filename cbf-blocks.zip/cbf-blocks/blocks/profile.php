<?php 
// Prevent direct access to the file
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

use Carbon_Fields\Block;
use Carbon_Fields\Field;

Block::make( __( 'User Profile' ) )
	->add_fields( array(
		Field::make( 'image', 'cbf-image', __( 'User Image' ) ),
		Field::make( 'text', 'cbf-name', __( 'User Name' ) ),
		Field::make( 'rich_text', 'cbf-content', __( 'User Details' ) )
	) )
	->set_category( 'cbf-blocks-category', __( 'CBF Blocks' ), 'cbf-blocks' )
	->set_render_callback( function ( $fields, $attributes, $inner_blocks ) {
		?>

		<div class="block">
			<div class="block__heading_profile">
				<?php echo wp_get_attachment_image( $fields['cbf-image'], 'full' ); ?>
				<h4><?php echo esc_html( $fields['cbf-name'] ); ?></h4>
				<?php echo apply_filters( 'the_content', $fields['cbf-content'] ); ?>
			</div><!-- /.block__heading -->
		</div><!-- /.block -->

		<?php
	} );