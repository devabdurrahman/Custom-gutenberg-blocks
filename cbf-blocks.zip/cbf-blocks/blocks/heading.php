<?php 
// Prevent direct access to the file
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

use Carbon_Fields\Block;
use Carbon_Fields\Field;

Block::make( __( 'CBF Heading' ) )
	->add_fields( array(
		Field::make( 'text', 'cbf-heading', __( 'CBF Heading' ) )
	) )
	->set_category( 'cbf-blocks-category', __( 'CBF Blocks' ), 'cbf-blocks' )
	->set_render_callback( function ( $fields, $attributes, $inner_blocks ) {
		?>

		<div class="block">
			<div class="block__heading">
				<h1><?php echo esc_html( $fields['cbf-heading'] ); ?></h1>
			</div><!-- /.block__heading -->
		</div><!-- /.block -->

		<?php
	} );