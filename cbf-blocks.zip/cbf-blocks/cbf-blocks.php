<?php
/*
 * Plugin Name:       CBF Blocks
 * Plugin URI:        devabdurrahman.com
 * Description:       Custom Blocks for Guetenberg made with Carbon Fields.
 * Version:           1.0
 * Requires at least: 5.2
 * Requires PHP:      7.2
 * Author:            Abdur Rahman
 * Author URI:        devabdurrahman.com
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       cbf-blocks
 * Domain Path:       /languages
 */

// Prevent direct access to the file
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

// Plugins loaded hook implementation
function cbf_plugins_loaded() {
    load_plugin_textdomain('cbf-blocks', false, plugin_dir_url(__FILE__) . "languages"); 

    if ( ! class_exists( '\Carbon_Fields\Carbon_Fields' ) ) {
        require_once plugin_dir_path(__FILE__) . 'carbon-fields/vendor/autoload.php';
        \Carbon_Fields\Carbon_Fields::boot();
    }
}
add_action("plugins_loaded", "cbf_plugins_loaded");

//Registering all blocks
add_action('carbon_fields_register_fields', 'cbf_register_all_blocks');
function cbf_register_all_blocks() {
    require_once plugin_dir_path(__FILE__) . 'blocks/heading.php';
    require_once plugin_dir_path(__FILE__) . 'blocks/profile.php';
    require_once plugin_dir_path(__FILE__) . 'blocks/image-card.php';
    require_once plugin_dir_path(__FILE__) . 'blocks/slider.php';
}

//Enqueue Gutenberg Block Editor Assets (JS/CSS)
add_action('enqueue_block_assets', 'cbf_enqueue_block_styles');
function cbf_enqueue_block_styles() {

    // CSS files
    wp_enqueue_style( 'cbf-block-css', plugin_dir_url(__FILE__) . 'assets/css/block.css', [], time() );
    wp_enqueue_style( 'cbf-flickity-css', plugin_dir_url(__FILE__) . 'assets/css/flickity.css', [], time() );

    // JS files
    wp_enqueue_script( 'cbf-flickity-js', plugin_dir_url(__FILE__) . 'assets/js/flickity.pkgd.min.js', [], time(), true );

}

